from jarvis.service import main
if __name__ == "__main__":
    main()
