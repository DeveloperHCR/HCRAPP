package com.developerhcr.codeassist;

import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

public final class AndroidApiBridge {
    private final Context context;
    private final SharedPreferences prefs;

    public AndroidApiBridge(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = context.getSharedPreferences("developerhcr", Context.MODE_PRIVATE);
    }

    @JavascriptInterface
    public String api(String path, String method, String body) {
        // Android APK is standalone: never connect to localhost, Termux or a browser server.
        return offlineResponse(path, method, body);
    }

    private String hash(String value) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] out = md.digest(value.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        for (byte b : out) sb.append(String.format(Locale.US, "%02x", b));
        return sb.toString();
    }

    private JSONObject bodyObject(String body) {
        try { return body == null || body.isEmpty() ? new JSONObject() : new JSONObject(body); }
        catch (Exception e) { return new JSONObject(); }
    }

    private String offlineResponse(String path, String method, String body) {
        try {
            if (path.startsWith("/api/auth/status")) {
                boolean configured = prefs.contains("username") && prefs.contains("password_hash");
                return "{\"admin_configured\":" + configured + ",\"owner_configured\":" + configured + ",\"friends_access_configured\":false,\"subscriber_access_configured\":false}";
            }
            if (path.startsWith("/api/auth/setup") && "POST".equalsIgnoreCase(method)) {
                JSONObject b = bodyObject(body);
                String u=b.optString("username","").trim(), pw=b.optString("password","");
                if(u.length()<3 || pw.length()<8) return "{\"error\":\"Username must be 3+ characters and password 8+ characters.\"}";
                try { prefs.edit().putString("username",u).putString("password_hash",hash(pw)).putBoolean("session",true).apply(); } catch(Exception e){ return "{\"error\":\"Could not secure local credentials.\"}"; }
                return "{\"user\":{" + "\"id\":1,\"username\":" + JSONObject.quote(u) + ",\"role\":\"ADMIN\",\"status\":\"active\"}}";
            }
            if (path.startsWith("/api/auth/login") && "POST".equalsIgnoreCase(method)) {
                JSONObject b=bodyObject(body); String u=b.optString("username","").trim(), pw=b.optString("password","");
                String su=prefs.getString("username",""); String sh=prefs.getString("password_hash","");
                try { if(!u.equalsIgnoreCase(su) || sh.isEmpty() || !hash(pw).equals(sh)) return "{\"error\":\"Incorrect username or password.\"}"; prefs.edit().putBoolean("session",true).apply(); } catch(Exception e){ return "{\"error\":\"Secure login failed.\"}"; }
                return "{\"logged_in\":true,\"user\":{" + "\"id\":1,\"username\":" + JSONObject.quote(su) + ",\"role\":\"ADMIN\",\"status\":\"active\"}}";
            }
            if (path.startsWith("/api/auth/logout")) { prefs.edit().putBoolean("session",false).apply(); return "{\"ok\":true}"; }
            if (path.startsWith("/api/auth/factory-reset") && "POST".equalsIgnoreCase(method)) {
                JSONObject b=bodyObject(body);
                if (!"RESET".equals(b.optString("confirm",""))) return "{\"error\":\"Reset confirmation required.\"}";
                try { prefs.edit().clear().commit(); context.getSharedPreferences("WebView", Context.MODE_PRIVATE).edit().clear().apply(); return "{\"ok\":true,\"message\":\"All local app data reset.\"}"; }
                catch(Exception e){ return "{\"error\":\"Could not reset local app data.\"}"; }
            }

            if (path.startsWith("/api/auth/me")) {
                boolean configured=prefs.contains("username") && prefs.contains("password_hash") && prefs.getBoolean("session",false);
                if(!configured) return "{\"logged_in\":false}";
                return "{\"logged_in\":true,\"user\":{" + "\"id\":1,\"username\":" + JSONObject.quote(prefs.getString("username","Android User")) + ",\"role\":\"ADMIN\",\"status\":\"active\"}}";
            }
            if (path.startsWith("/api/auth/quick-status")) return "{\"enabled\":false}";
            if (path.startsWith("/api/account/credentials") && "POST".equalsIgnoreCase(method)) {
                JSONObject b=bodyObject(body); String old=b.optString("current_password",""), np=b.optString("new_password",""); String sh=prefs.getString("password_hash","");
                try { if(sh.isEmpty() || !hash(old).equals(sh)) return "{\"error\":\"Current password is incorrect.\"}"; if(np.length()>=8) prefs.edit().putString("password_hash",hash(np)).apply(); String nu=b.optString("new_username",prefs.getString("username","Admin")); if(nu.length()>=3) prefs.edit().putString("username",nu).apply(); return "{\"ok\":true,\"message\":\"Account updated locally.\",\"user\":{" + "\"id\":1,\"username\":" + JSONObject.quote(prefs.getString("username","Admin")) + ",\"role\":\"ADMIN\"}}"; } catch(Exception e){return "{\"error\":\"Could not update credentials.\"}";}
            }
            if (path.startsWith("/api/settings")) {
                JSONObject o = new JSONObject();
                o.put("sound_enabled", true);
                o.put("sound_volume", 0.45);
                o.put("theme", "dark");
                o.put("zoom", 1.0);
                o.put("fullscreen", true);
                return o.toString();
            }
            if (path.startsWith("/api/access/features")) {
                return "{\"plan\":\"ANDROID_LOCAL\",\"features\":[\"all\"],\"restricted\":false}";
            }
            if (path.startsWith("/api/ai/models")) {
                return "{\"ollama\":{\"installed\":false,\"running\":false,\"models\":[],\"error\":\"AI runtimes are not bundled; offline GUI mode remains available.\"},\"gguf_models\":[],\"gguf_search_dirs\":[],\"llama_cpp_python_installed\":false,\"note\":\"Android GUI mode does not fabricate AI models.\"}";
            }
            if (path.startsWith("/api/ai/providers")) return "{\"providers\":[]}";
            if (path.startsWith("/api/ai/conversations")) return "{\"conversations\":[]}";
            if (path.startsWith("/api/notes")) return "{\"notes\":[]}";
            if (path.startsWith("/api/files")) return "{\"path\":\"\",\"items\":[],\"home\":\"Android app storage\"}";
            if (path.startsWith("/api/vault")) return "{\"items\":[]}";
            if (path.startsWith("/api/games")) return "{\"games\":[]}";
            if (path.startsWith("/api/store")) return "{\"apps\":[],\"installed\":[]}";
            if (path.startsWith("/api/plans")) return "{\"plans\":[]}";
            if (path.startsWith("/api/subscriptions")) return "{\"requests\":[]}";
            if (path.startsWith("/api/access/status")) return "{\"mode\":\"ANDROID_LOCAL\",\"authenticated\":true}";
            if (path.startsWith("/api/system")) return "{\"platform\":\"Android\",\"mode\":\"GUI\",\"offline\":true}";
            if (path.startsWith("/api/health")) return "{\"status\":\"ok\",\"mode\":\"Android GUI\"}";
            if (path.startsWith("/api/app-health")) return "{\"status\":\"ok\",\"checks\":[]}";
            if (path.startsWith("/api/control-center")) return "{\"status\":\"Android GUI\",\"network\":\"available\",\"bluetooth\":\"device-controlled\"}";
            if (path.startsWith("/api/jarvis/status")) return "{\"available\":false,\"message\":\"Assistant runtime is not bundled into the APK.\"}";
            if (path.startsWith("/api/jarvis/ai-runtimes")) return "{\"runtimes\":[]}";
            if (path.startsWith("/api/terminal/run")) return "{\"ok\":false,\"output\":\"Terminal backend is not bundled. This APK does not require Termux or Python.\"}";
            if (path.startsWith("/api/toolchains")) return "{\"toolchains\":[]}";
            if (path.startsWith("/api/repository/status")) return "{\"status\":\"local\",\"remote\":false}";
            if (path.startsWith("/api/updates/check")) return "{\"available\":false,\"message\":\"Update service is disabled in offline APK mode.\"}";
            if (path.startsWith("/api/diagnostics")) return "{\"checks\":[{\"name\":\"Offline mode\",\"ok\":true,\"detail\":\"No network permission or server connection is required.\"},{\"name\":\"Android GUI\",\"ok\":true,\"detail\":\"WebView desktop shell loaded.\"},{\"name\":\"Local security\",\"ok\":true,\"detail\":\"Credentials are stored as local password hashes.\"}]}";
            if (path.startsWith("/api/processes")) return "{\"processes\":[]}";
            if (path.startsWith("/api/downloads/files")) return "{\"files\":[]}";
            if (path.startsWith("/api/feedback")) return "{\"ok\":true}";
            if (path.startsWith("/api/security/settings")) return "{\"quick_unlock_enabled\":false,\"privacy_mode\":\"private\"}";
            if (path.startsWith("/api/agreements/status")) return "{\"accepted\":true}";
            if (path.startsWith("/api/guest/status")) return "{\"active\":false}";
            if (path.startsWith("/api/trading/practice/state")) return "{\"cash\":100000,\"positions\":[],\"orders\":[]}";
            if (path.startsWith("/api/trading/live/status")) return "{\"available\":false,\"connected\":false}";
            if (path.startsWith("/api/exe/status")) return "{\"available\":false,\"message\":\"Windows runtime is not bundled in Android APK.\"}";
            if (path.startsWith("/api/exe/list")) return "{\"items\":[]}";
            // Generic successful response keeps optional UI panels from crashing.
            return "{\"ok\":true,\"items\":[],\"data\":[],\"message\":\"Android GUI offline compatibility mode\"}";
        } catch (Exception e) {
            return "{\"error\":\"Android compatibility response failed\"}";
        }
    }
}
