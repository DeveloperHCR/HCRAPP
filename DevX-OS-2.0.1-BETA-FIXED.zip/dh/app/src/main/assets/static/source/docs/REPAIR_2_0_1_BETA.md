# DevX OS 2.0.1 BETA Repair

- Fixed-size responsive boot and Create Admin screens.
- Added explicit Run as Guest mode with a 1-minute session.
- Guest mode exposes only selected basic apps; it never receives the full feature set.
- Settings window launch now has defensive error handling.
- Setup Center links to Environment and recovery tools.
- Guest sessions are automatically cleaned up after expiry.
