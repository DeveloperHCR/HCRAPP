/*
 * Android bridge for DeveloperHCR Code Assist.
 * The original web UI is preserved. Android supplies a lightweight local API
 * compatibility layer and can optionally proxy requests to a local backend
 * such as the existing Termux/Python server on 127.0.0.1:8000.
 */
(function () {
  "use strict";
  if (!window.AndroidHCR) return;

  const realFetch = window.fetch.bind(window);
  const isApi = (u) => {
    try { return new URL(u, location.href).pathname.startsWith("/api/"); }
    catch (_) { return String(u).indexOf("/api/") >= 0; }
  };

  window.fetch = function(input, init) {
    const url = typeof input === "string" ? input : (input && input.url) || "";
    if (!isApi(url)) return realFetch(input, init);

    const method = (init && init.method) || "GET";
    const body = (init && init.body) || "";
    let path = url;
    try { path = new URL(url, location.href).pathname + new URL(url, location.href).search; } catch (_) {}

    try {
      const raw = window.AndroidHCR.api(path, method, String(body));
      const payload = raw || JSON.stringify({error:"Android API bridge returned no data"});
      return Promise.resolve(new Response(payload, {
        status: 200,
        headers: {"Content-Type":"application/json"}
      }));
    } catch (e) {
      return Promise.resolve(new Response(JSON.stringify({error:String(e && e.message || e)}), {
        status: 200,
        headers: {"Content-Type":"application/json"}
      }));
    }
  };
})();
