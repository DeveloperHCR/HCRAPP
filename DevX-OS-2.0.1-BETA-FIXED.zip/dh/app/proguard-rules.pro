# DeveloperHCR Code Assist - no custom rules required.
