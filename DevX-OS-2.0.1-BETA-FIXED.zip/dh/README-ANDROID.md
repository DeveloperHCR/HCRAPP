# DevHCR APP — Android Gradle project

This project packages the existing DeveloperHCR web desktop UI as a real Android APK.

## What was preserved
- The original `static/` desktop GUI, CSS, JavaScript and bundled assets.
- The original Python backend/source is included under `app/src/main/assets/source/` for reference and optional Termux/server use.
- Windows-style desktop, taskbar, app launcher, movable windows and the existing DeveloperHCR UI are retained.

## Android layer
- Native Java Android Activity.
- Full-screen landscape presentation.
- Android WebView hosts the existing GUI.
- `AndroidApiBridge` provides an offline compatibility API so the GUI can open without a Python server.
- If the existing Python/FastAPI server is running locally on `127.0.0.1:8000` (for example through Termux), the bridge tries that backend first.
- The APK does NOT pretend that Ollama, Python, Wine, Windows EXE execution, or native Linux tools are bundled. Those remain optional external runtimes.

## Build
Open this folder in Android Studio, allow Gradle sync, then:
- Build > Make Project
- Build > Build APK(s)

Command line, when Gradle/Android SDK are installed:
`./gradlew assembleDebug`

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Important
The original project is a Python/FastAPI application, not an Android Gradle application. This Gradle project is therefore an Android GUI/container port, not a direct conversion of FastAPI into Java. The original backend is preserved in the project so it can continue to be run separately (for example in Termux).

## Project identity
DevHCR APP / Code Assist
Version: 1.0-beta
Created by Abhimanyu Verma

## Android visual fix
The Android build uses local relative asset paths so the GUI loads correctly from `android_asset`. The supplied DeveloperHCR image is used as the boot/login/desktop background and application icon.
