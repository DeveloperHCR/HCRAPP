# DevHCR APP — Android standalone mode

## Runtime model

This Android build is a native Java APK containing the DeveloperHCR GUI in its bundled WebView assets.
It does not require a browser, localhost, Python server, FastAPI, Termux, or an internet connection to open the desktop GUI.

The Android bridge handles the UI compatibility API locally. It does not proxy API requests to `127.0.0.1:8000`.

## Security

- First launch creates a local Admin username and password.
- Passwords are stored as SHA-256 hashes in Android SharedPreferences; the plaintext password is not stored.
- Login is required again after a fresh app process unless a future secure session policy explicitly keeps it.
- Account password changes are available from Settings > Account & Login.
- Core UI preferences are stored locally.

## Interaction

- One tap/click: normal selection / left-click behavior.
- Press and move: drag and drop where the target supports it.
- Desktop windows can be moved, resized, minimized, maximized and closed.
- Pointer visibility is controlled from Settings > Desktop > Pointer.
- The Android UI uses custom vector-drawn app icons instead of emoji icons.

## Offline-first behavior

The GUI, settings, authentication shell, local utilities and bundled assets work offline.
Features that inherently require an external service/runtime are shown as unavailable rather than pretending they work, for example remote updates, live web browsing, cloud AI and external downloads.

## Support

DeveloperHCR Support Team

Email: developerhcr@gmail.com
Instagram: @developerhcr
GitHub: DeveloperHCR/HCRAPP

WhatsApp support is not included in this build.
