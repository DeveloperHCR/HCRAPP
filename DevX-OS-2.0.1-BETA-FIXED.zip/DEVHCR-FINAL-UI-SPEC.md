# DevHCR APP — final UI behavior

- First launch always starts with the Admin Setup/Login screen.
- Main desktop uses an immersive, video-like fullscreen layout.
- Windows keep title bars and minimize / maximize-restore / close controls.
- Windows are movable and resizable within screen bounds.
- One tap is normal selection; press-and-drag is drag/drop.
- Pointer visibility is configurable in Settings.
- Start menu opens without forcing the software keyboard; text fields request the keyboard only when focused.
- Optional desktop items can be shown/hidden from Settings.
- Notifications, pointer, camera and microphone are app-local features.
- Camera and microphone use Android runtime permissions.
- Browser is intended to open inside the app's WebView/internal browser surface rather than handing off to an external browser.
- Offline dashboard metrics fall back to 0 instead of crashing when a backend is unavailable.
- Troubleshoot provides diagnostics and reset-data flow.
- No localhost/Termux/Python service is required for the GUI.
