# DevX OS Sound Map

Each major app/system action has its own short, original WAV sound. The sounds are separated so the app can later map them to individual UI actions.

- `system_startup.wav` — unique sound for `system_startup`
- `desktop_open.wav` — unique sound for `desktop_open`
- `file_manager.wav` — unique sound for `file_manager`
- `recycle_bin.wav` — unique sound for `recycle_bin`
- `this_pc.wav` — unique sound for `this_pc`
- `setup.wav` — unique sound for `setup`
- `settings.wav` — unique sound for `settings`
- `ai_chat.wav` — unique sound for `ai_chat`
- `browser.wav` — unique sound for `browser`
- `internet_online.wav` — unique sound for `internet_online`
- `internet_offline.wav` — unique sound for `internet_offline`
- `calculator.wav` — unique sound for `calculator`
- `text_editor.wav` — unique sound for `text_editor`
- `image_viewer.wav` — unique sound for `image_viewer`
- `pdf_viewer.wav` — unique sound for `pdf_viewer`
- `downloader.wav` — unique sound for `downloader`
- `system_monitor.wav` — unique sound for `system_monitor`
- `network_tools.wav` — unique sound for `network_tools`
- `code_editor.wav` — unique sound for `code_editor`
- `python_app_builder.wav` — unique sound for `python_app_builder`
- `troubleshoot.wav` — unique sound for `troubleshoot`
- `recovery.wav` — unique sound for `recovery`
- `notification.wav` — unique sound for `notification`
- `success.wav` — unique sound for `success`
- `error.wav` — unique sound for `error`
