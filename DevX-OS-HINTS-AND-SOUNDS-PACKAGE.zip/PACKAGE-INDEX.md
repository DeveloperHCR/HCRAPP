# DevX OS Hint Package

## Structure

- `MAIN_HINT.md` — main hint at package root.
- `HINTS/` — feature/app hints organized into separate folders.
- `PRIVATE_HINTS/` — legitimate owner-only documentation placeholders; no real secrets.
- `SOUNDS/` — unique original sounds for apps/system actions.
- `CAL/` — reserved CAL folder as requested.
