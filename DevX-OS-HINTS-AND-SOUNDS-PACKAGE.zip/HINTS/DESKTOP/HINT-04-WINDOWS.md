# HINT 04 WINDOWS

Windows — explains minimize, maximize, close and resizing.

## Hint

This is a structured placeholder for the feature-specific hint. The final project hint text/link can be added here later.

> Do not put passwords, API keys, tokens, or authentication-bypass instructions in hint files.
