# CAL

Reserved folder for future call/communication-related assets and hints.
