# DevX OS V3.5.0 — source release fixes

This is a source ZIP based on the previously supplied DevX OS V3.4.1 project. The Android APK was not built in this environment.

## Fixes

- Canonical taskbar Search: one button and one SVG magnifier; removes secondary icon controls, nested icon wrappers, and search pseudo-artwork while keeping the existing Start/Search behavior.
- Floating Permissions cleanup: removes the desktop shortcut but preserves Permission Center inside Settings, Start/Search, and Quick Settings. Quick Settings keeps one Permissions entry next to the network/airplane controls.
- Admin session menu: ADMIN/GUEST is a real button; one tap opens Remember me ON/OFF, Shut down DevX OS interface, Reboot DevX OS interface, and Log out. Remember me is only a preference and never skips authentication.
- Window layering: opaque app surfaces prevent inactive dashboard/settings text from bleeding through windows.
- Recovery card: Local Backup & Recovery is created inside the Settings window, not on the bare desktop. The existing export/restore preference backup helper is retained.
- Version labels: visible app labels identify V3.0 RELEASE; Android versionCode is 30 and versionName is 3.0.
- Android Drive: browse subfolders beneath a folder explicitly approved with Android's Storage Access Framework picker. Protected Android system/app directories remain restricted by Android.
- AI: retains visible provider/model status and error handling; a runnable local model or configured API provider is still required for actual responses.
- First-run splash: 10 seconds only on the first visit, using local storage to remember it.

## Checks

- Runtime and source app.js syntax checked with Node.js.
- Runtime and source release enhancement JavaScript syntax checked with Node.js.
- Key source invariants checked in both runtime and source copies.
- ZIP archive integrity checked after packaging.
- Android APK compilation and physical-device verification were not performed.
