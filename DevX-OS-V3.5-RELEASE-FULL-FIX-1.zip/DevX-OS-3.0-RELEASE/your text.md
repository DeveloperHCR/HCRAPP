# DevX OS 2.0.3 BETA — Fix Notes

## Internet / Online Status
- Reworked Android Internet detection.
- Uses Android's validated network capability when available.
- Falls back to direct HTTPS connectivity probes when validation is unavailable.
- Added multiple HTTPS endpoints and broader successful-response handling.
- Reduced stale network-status caching.
- Added a force network-check bridge for the UI.
- Clicking the Online/Offline status now performs a fresh check.
- `Online` means the app has verified real Internet access; a local Wi-Fi/mobile connection alone is not treated as Internet access.
- Troubleshooting and the desktop network indicator use the same status logic.

## Diagnostics
- Invalid JSON from diagnostics is handled safely instead of breaking the Troubleshoot window.
- Network details are retained internally for clearer diagnostics.

## Icons / UI
- Kept the existing SVG icon system.
- Added icon-first treatment to several previously glyph/emoji-looking headings and controls.
- Improved the network-status control with a proper icon and clickable refresh behavior.
- Existing desktop/window/taskbar icon decoration remains enabled.

## Important Build Note
The source has been updated and JavaScript syntax was checked in this environment. A full Android APK compilation was not claimed because a usable Gradle executable/distribution is not available in this build environment.

## Private Data
No passwords, API keys, authentication tokens, hidden credentials, or other real secrets are included in this source package. Private configuration is supplied separately as a template ZIP so the owner can add their own values locally.
