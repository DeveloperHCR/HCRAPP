# DevX OS 2.0.2 — Real Internet & Diagnostics Fix

The Android build no longer treats a stale WebView `navigator.onLine` value as authoritative.

Online is shown only when:
1. Android reports an active network with Internet capability, and
2. the network is either validated by Android or passes a short HTTPS connectivity probe.

The login Troubleshoot panel now shows the same verified status, and diagnostics safely handles malformed/non-JSON responses without exposing a JSON parser error to the user.


Manifest requirement: declare both `android.permission.INTERNET` and `android.permission.ACCESS_NETWORK_STATE`; the latter is required to read Android network capabilities. The Settings “Check Internet” action forces a fresh native connectivity probe.
