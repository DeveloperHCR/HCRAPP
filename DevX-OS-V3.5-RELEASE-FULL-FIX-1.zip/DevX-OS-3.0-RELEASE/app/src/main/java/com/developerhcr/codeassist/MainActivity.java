package com.developerhcr.codeassist;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.PermissionRequest;

public class MainActivity extends Activity {
    private WebView webView;
    private AndroidApiBridge bridge;
    private PermissionRequest pendingWebPermission;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUserAgentString(s.getUserAgentString() + " DeveloperHCR-CodeAssist/Android");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                return super.onShowFileChooser(w, cb, params);
            }
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean needsCamera = false, needsMic = false;
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) needsCamera = true;
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) needsMic = true;
                    }
                    boolean cameraOk = !needsCamera || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
                    boolean micOk = !needsMic || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
                    if (cameraOk && micOk) {
                        request.grant(request.getResources());
                    } else {
                        pendingWebPermission = request;
                        java.util.ArrayList<String> ask = new java.util.ArrayList<>();
                        if (!cameraOk) ask.add(Manifest.permission.CAMERA);
                        if (!micOk) ask.add(Manifest.permission.RECORD_AUDIO);
                        requestPermissions(ask.toArray(new String[0]), AndroidApiBridge.REQUEST_PERMISSIONS + 1);
                    }
                });
            }
        });
        bridge = new AndroidApiBridge(this);
        webView.addJavascriptInterface(bridge, "AndroidHCR");
        setContentView(webView);
        hideSystemUi();
        webView.loadUrl("file:///android_asset/static/index.html");
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == AndroidApiBridge.REQUEST_PERMISSIONS || requestCode == AndroidApiBridge.REQUEST_PERMISSIONS + 1) {
            if (requestCode == AndroidApiBridge.REQUEST_PERMISSIONS + 1 && pendingWebPermission != null) {
                boolean cameraOk = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
                boolean micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
                boolean needsCamera = false, needsMic = false;
                for (String r : pendingWebPermission.getResources()) {
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) needsCamera = true;
                    if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) needsMic = true;
                }
                if ((!needsCamera || cameraOk) && (!needsMic || micOk)) pendingWebPermission.grant(pendingWebPermission.getResources());
                else pendingWebPermission.deny();
                pendingWebPermission = null;
            }
            if (webView != null) {
                String js = "window.dispatchEvent(new CustomEvent('android-permissions-result',{detail:" +
                        JSONObjectEscaper.quote(bridge.permissionStatus()) + "}));";
                webView.post(() -> webView.evaluateJavascript(js, null));
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == AndroidApiBridge.REQUEST_STORAGE_TREE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                final int takeFlags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                getContentResolver().takePersistableUriPermission(uri, takeFlags);
            } catch (Exception ignored) { }
            getSharedPreferences("developerhcr", MODE_PRIVATE).edit().putString("storage_tree_uri", uri.toString()).apply();
            if (webView != null) {
                String js = "window.dispatchEvent(new CustomEvent('android-storage-result',{detail:" + JSONObjectEscaper.quote(uri.toString()) + "}));";
                webView.post(() -> webView.evaluateJavascript(js, null));
            }
        }
    }

    static final class JSONObjectEscaper {
        static String quote(String value) {
            if (value == null) return "\"\"";
            return org.json.JSONObject.quote(value);
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onResume() {
        super.onResume();
        hideSystemUi();
        if (webView != null) {
            webView.postDelayed(() -> webView.evaluateJavascript(
                    "window.__devxRefreshNetwork && window.__devxRefreshNetwork();", null), 250);
        }
    }

}
