package com.developerhcr.codeassist;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.os.BatteryManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.provider.DocumentsContract;
import android.database.Cursor;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Locale;

public final class AndroidApiBridge {
    public static final int REQUEST_PERMISSIONS = 4901;
    public static final int REQUEST_STORAGE_TREE = 4902;

    private final Activity activity;
    private final Context context;
    private final SharedPreferences prefs;
    private volatile long networkCheckAt = 0L;
    private volatile boolean networkCheckResult = false;
    private volatile String networkCheckDetail = "Not checked yet";

    public AndroidApiBridge(Context context) {
        this.activity = context instanceof Activity ? (Activity) context : null;
        this.context = context.getApplicationContext();
        this.prefs = context.getSharedPreferences("developerhcr", Context.MODE_PRIVATE);
    }


    @JavascriptInterface
    public boolean openExternalUrl(String url) {
        try {
            if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) return false;
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            return true;
        } catch (Exception e) { return false; }
    }

    @JavascriptInterface
    public boolean networkConnected() {
        return isOnline(false);
    }

    @JavascriptInterface
    public boolean forceNetworkCheck() {
        networkCheckAt = 0L;
        return isOnline(true);
    }

    @JavascriptInterface
    public String networkStatus() {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            JSONObject o = new JSONObject();
            boolean online = isOnline(false);
            o.put("online", online);
            o.put("validated", false);
            o.put("internet_capability", false);
            o.put("transport", "unknown");
            o.put("detail", networkCheckDetail);
            if (cm != null && Build.VERSION.SDK_INT >= 23) {
                Network n = cm.getActiveNetwork();
                NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
                if (c != null) {
                    boolean validated = c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
                    boolean internet = c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
                    o.put("validated", validated);
                    o.put("internet_capability", internet);
                    if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) o.put("transport", "wifi");
                    else if (c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) o.put("transport", "cellular");
                    else if (c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) o.put("transport", "ethernet");
                    else if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) o.put("transport", "vpn");
                }
            }
            return o.toString();
        } catch (Exception e) {
            return "{\"online\":" + isOnline(false) + ",\"transport\":\"unknown\",\"detail\":\"status unavailable\"}";
        }
    }

    @JavascriptInterface
    public boolean openSettings(String action) {
        try {
            Intent i;
            if ("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION".equals(action)) {
                i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + context.getPackageName()));
            } else if ("android.settings.APP_NOTIFICATION_SETTINGS".equals(action)) {
                i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                i.putExtra(Settings.EXTRA_APP_PACKAGE, context.getPackageName());
                i.putExtra(Settings.EXTRA_CHANNEL_ID, "devx_os_alerts");
            } else {
                i = new Intent(action);
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            return true;
        } catch (Exception e) {
            try {
                Intent i = new Intent(Settings.ACTION_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
                return true;
            } catch (Exception ignored) { return false; }
        }
    }

    @JavascriptInterface
    public String permissionStatus() {
        try {
            JSONObject o = new JSONObject();
            o.put("camera", granted(Manifest.permission.CAMERA));
            o.put("microphone", granted(Manifest.permission.RECORD_AUDIO));
            o.put("notifications", notificationAllowed());
            o.put("bluetooth_scan", Build.VERSION.SDK_INT < 31 || granted(Manifest.permission.BLUETOOTH_SCAN));
            o.put("bluetooth_connect", Build.VERSION.SDK_INT < 31 || granted(Manifest.permission.BLUETOOTH_CONNECT));
            o.put("media_images", Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.READ_MEDIA_IMAGES));
            o.put("media_video", Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.READ_MEDIA_VIDEO));
            o.put("media_audio", Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.READ_MEDIA_AUDIO));
            o.put("legacy_storage", Build.VERSION.SDK_INT < 33 && granted(Manifest.permission.READ_EXTERNAL_STORAGE));
            o.put("all_files_access", Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager());
            o.put("selected_storage_tree", prefs.getString("storage_tree_uri", ""));
            o.put("api_level", Build.VERSION.SDK_INT);
            return o.toString();
        } catch (Exception e) { return "{\"error\":\"Permission status unavailable\"}"; }
    }

    @JavascriptInterface
    public boolean requestPermissions(String csv) {
        if (activity == null || Build.VERSION.SDK_INT < 23) return false;
        String[] raw = (csv == null ? "" : csv).split(",");
        java.util.ArrayList<String> req = new java.util.ArrayList<>();
        for (String x : raw) {
            String p = x.trim();
            if ("camera".equalsIgnoreCase(p)) req.add(Manifest.permission.CAMERA);
            else if ("microphone".equalsIgnoreCase(p) || "audio".equalsIgnoreCase(p)) req.add(Manifest.permission.RECORD_AUDIO);
            else if ("notifications".equalsIgnoreCase(p) && Build.VERSION.SDK_INT >= 33) req.add(Manifest.permission.POST_NOTIFICATIONS);
            else if ("bluetooth".equalsIgnoreCase(p) && Build.VERSION.SDK_INT >= 31) {
                req.add(Manifest.permission.BLUETOOTH_SCAN); req.add(Manifest.permission.BLUETOOTH_CONNECT);
            }
            else if ("media".equalsIgnoreCase(p) && Build.VERSION.SDK_INT >= 33) {
                req.add(Manifest.permission.READ_MEDIA_IMAGES); req.add(Manifest.permission.READ_MEDIA_VIDEO); req.add(Manifest.permission.READ_MEDIA_AUDIO);
            }
            else if ("legacy_storage".equalsIgnoreCase(p) && Build.VERSION.SDK_INT <= 32) req.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (req.isEmpty()) return false;
        activity.requestPermissions(req.toArray(new String[0]), REQUEST_PERMISSIONS);
        return true;
    }

    @JavascriptInterface
    public boolean openStoragePicker() {
        if (activity == null) return false;
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
            activity.startActivityForResult(i, REQUEST_STORAGE_TREE);
            return true;
        } catch (Exception e) { return false; }
    }

    @JavascriptInterface
    public String selectedStorageList() {
        return selectedStorageListAt("");
    }

    /** Lists the immediate children of the user-granted Storage Access Framework folder. */
    @JavascriptInterface
    public String selectedStorageListAt(String requestedDocumentId) {
        Cursor c = null;
        try {
            String tree = prefs.getString("storage_tree_uri", "");
            if (tree.isEmpty()) return "{\"selected\":false,\"items\":[]}";
            Uri treeUri = Uri.parse(tree);
            String rootDocumentId = DocumentsContract.getTreeDocumentId(treeUri);
            String documentId = (requestedDocumentId == null || requestedDocumentId.trim().isEmpty())
                    ? rootDocumentId : requestedDocumentId;
            // The URI always remains rooted at the persisted, user-approved tree grant.
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, documentId);
            c = context.getContentResolver().query(children,
                    new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                            DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE, DocumentsContract.Document.COLUMN_LAST_MODIFIED},
                    null, null, DocumentsContract.Document.COLUMN_DISPLAY_NAME + " COLLATE NOCASE ASC");
            org.json.JSONArray arr = new org.json.JSONArray();
            if (c != null) {
                while (c.moveToNext()) {
                    JSONObject item = new JSONObject();
                    item.put("id", c.getString(0));
                    item.put("name", c.getString(1));
                    item.put("mime", c.getString(2));
                    item.put("is_dir", "vnd.android.document/directory".equals(c.getString(2)));
                    item.put("size", c.isNull(3) ? 0 : c.getLong(3));
                    item.put("modified", c.isNull(4) ? 0 : c.getLong(4));
                    arr.put(item);
                }
            }
            return new JSONObject().put("selected", true).put("root_uri", tree)
                    .put("current_document_id", documentId).put("items", arr).toString();
        } catch (Exception e) {
            return "{\"selected\":false,\"items\":[],\"error\":\"Could not read this Android folder. Choose a folder that Android allows the app to access.\"}";
        } finally { if (c != null) try { c.close(); } catch (Exception ignored) { } }
    }

    @JavascriptInterface
    public boolean clearSelectedStorage() {
        try { prefs.edit().remove("storage_tree_uri").apply(); return true; } catch (Exception e) { return false; }
    }

    @JavascriptInterface
    public boolean notifyMessage(String title, String message, String type) {
        try {
            if (!notificationAllowed()) return false;
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            final String channelId = "devx_os_alerts";
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(channelId, "DevX OS alerts", NotificationManager.IMPORTANCE_DEFAULT);
                nm.createNotificationChannel(ch);
            }
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? new android.app.Notification.Builder(context, channelId)
                    : new android.app.Notification.Builder(context);
            b.setSmallIcon(com.developerhcr.codeassist.R.drawable.developerhcr_notify)
                    .setContentTitle(title == null ? "DevX OS" : title)
                    .setContentText(message == null ? "" : message)
                    .setAutoCancel(true);
            nm.notify((int)(System.currentTimeMillis() & 0x7fffffff), b.build());
            return true;
        } catch (Exception e) { return false; }
    }

    @JavascriptInterface
    public boolean openTermux() {
        try {
            Intent i = context.getPackageManager().getLaunchIntentForPackage("com.termux");
            if (i == null) return false;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            return true;
        } catch (Exception e) { return false; }
    }

    @JavascriptInterface
    public String api(String path, String method, String body) {
        return offlineResponse(path, method, body);
    }

    private boolean granted(String p) {
        return Build.VERSION.SDK_INT < 23 || context.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean notificationAllowed() {
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) return false;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return false;
        return Build.VERSION.SDK_INT < 24 || nm.areNotificationsEnabled();
    }

    private boolean isOnline() { return isOnline(false); }

    private boolean isOnline(boolean force) {
        final long now = SystemClock.elapsedRealtime();
        if (!force && networkCheckAt > 0L && now - networkCheckAt < 2000L) return networkCheckResult;
        boolean result = false;
        String detail = "No active network";
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) {
                detail = "Connectivity service unavailable";
            } else if (Build.VERSION.SDK_INT >= 23) {
                Network n = cm.getActiveNetwork();
                if (n != null) {
                    NetworkCapabilities c = cm.getNetworkCapabilities(n);
                    if (c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                        boolean validated = c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
                        if (validated) {
                            result = true;
                            detail = "Android validated Internet";
                        } else {
                            result = probeInternet(n);
                            detail = result ? "HTTPS Internet probe succeeded" : "Network connected, Internet probe failed";
                        }
                    } else {
                        detail = "Network has no Internet capability";
                    }
                }
            } else {
                android.net.NetworkInfo info = cm.getActiveNetworkInfo();
                result = info != null && info.isConnected();
                detail = result ? "Connected network (legacy Android)" : "No connected network";
            }
        } catch (Exception e) {
            detail = "Network check error";
            result = false;
        }
        networkCheckResult = result;
        networkCheckDetail = detail;
        networkCheckAt = now;
        return result;
    }

    private boolean probeInternet(Network network) {
        final String[] endpoints = new String[]{
                "https://connectivitycheck.gstatic.com/generate_204",
                "https://www.google.com/generate_204",
                "https://cp.cloudflare.com/",
                "https://example.com/"
        };
        for (String endpoint : endpoints) {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) network.openConnection(new URL(endpoint));
                conn.setConnectTimeout(3500);
                conn.setReadTimeout(3500);
                conn.setUseCaches(false);
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("Cache-Control", "no-cache, no-store");
                conn.setRequestProperty("Pragma", "no-cache");
                conn.setRequestProperty("User-Agent", "DevX-OS/2.0 Android Internet Check");
                conn.setRequestMethod("GET");
                int code = conn.getResponseCode();
                if (code == HttpURLConnection.HTTP_NO_CONTENT || (code >= 200 && code < 400)) return true;
            } catch (Exception ignored) {
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        return false;
    }

    private String hash(String value) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] out = md.digest(value.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        for (byte b : out) sb.append(String.format(Locale.US, "%02x", b));
        return sb.toString();
    }

    private JSONObject bodyObject(String body) {
        try { return body == null || body.isEmpty() ? new JSONObject() : new JSONObject(body); }
        catch (Exception e) { return new JSONObject(); }
    }

    private String systemStatusJson() {
        try {
            JSONObject o = new JSONObject();
            StatFs sf = new StatFs(context.getFilesDir().getAbsolutePath());
            long total = sf.getTotalBytes(), free = sf.getAvailableBytes();
            double usedPct = total > 0 ? ((double)(total - free) * 100.0 / (double)total) : 0.0;
            BatteryManager bm = (BatteryManager) context.getSystemService(Context.BATTERY_SERVICE);
            int battery = -1;
            if (bm != null && Build.VERSION.SDK_INT >= 21) { battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY); }
            o.put("platform", "Android");
            o.put("mode", "GUI");
            o.put("offline", !isOnline());
            o.put("online", isOnline());
            o.put("os", "Android");
            o.put("os_release", Build.VERSION.RELEASE);
            o.put("arch", Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "unknown");
            o.put("cpu_percent", 0);
            o.put("cpu_cores", Runtime.getRuntime().availableProcessors());
            Runtime rt = Runtime.getRuntime();
            long max = rt.maxMemory(), used = rt.totalMemory() - rt.freeMemory();
            o.put("ram_used_percent", max > 0 ? (double)used * 100.0 / (double)max : 0.0);
            o.put("ram_total_gb", max / 1024.0 / 1024.0 / 1024.0);
            o.put("battery_percent", battery);
            o.put("uptime_seconds", SystemClock.elapsedRealtime() / 1000.0);
            JSONObject disk = new JSONObject();
            disk.put("device", "App Storage");
            disk.put("mount", context.getFilesDir().getAbsolutePath());
            disk.put("total_gb", total / 1024.0 / 1024.0 / 1024.0);
            disk.put("free_gb", free / 1024.0 / 1024.0 / 1024.0);
            disk.put("used_percent", usedPct);
            disk.put("is_main", true);
            disk.put("likely_external", false);
            o.put("disks", new org.json.JSONArray().put(disk));
            return o.toString();
        } catch (Exception e) {
            return "{\"platform\":\"Android\",\"mode\":\"GUI\",\"online\":false,\"offline\":true,\"disks\":[]}";
        }
    }

    private String offlineResponse(String path, String method, String body) {
        try {
            if (path.startsWith("/api/auth/status")) {
                boolean configured = prefs.contains("username") && prefs.contains("password_hash");
                return "{\"admin_configured\":" + configured + ",\"owner_configured\":" + configured + ",\"friends_access_configured\":false,\"subscriber_access_configured\":false}";
            }
            if (path.startsWith("/api/auth/setup") && "POST".equalsIgnoreCase(method)) {
                JSONObject b = bodyObject(body);
                String u=b.optString("username","").trim(), pw=b.optString("password","");
                if(u.length()<3 || pw.length()<8) return "{\"error\":\"Username must be 3+ characters and password 8+ characters.\"}";
                try { prefs.edit().putString("username",u).putString("password_hash",hash(pw)).putBoolean("session",true).apply(); } catch(Exception e){ return "{\"error\":\"Could not secure local credentials.\"}"; }
                return "{\"user\":{" + "\"id\":1,\"username\":" + JSONObject.quote(u) + ",\"role\":\"ADMIN\",\"status\":\"active\"}}";
            }
            if (path.startsWith("/api/auth/login") && "POST".equalsIgnoreCase(method)) {
                JSONObject b=bodyObject(body); String u=b.optString("username","").trim(), pw=b.optString("password","");
                if(u.length()<3) return "{\"error\":\"Username must be at least 3 characters.\"}";
                String su=prefs.getString("username",""); String sh=prefs.getString("password_hash","");
                try { if(!u.equalsIgnoreCase(su) || sh.isEmpty() || !hash(pw).equals(sh)) return "{\"error\":\"Incorrect username or password.\"}"; prefs.edit().putBoolean("session",true).apply(); } catch(Exception e){ return "{\"error\":\"Secure login failed.\"}"; }
                return "{\"logged_in\":true,\"user\":{" + "\"id\":1,\"username\":" + JSONObject.quote(su) + ",\"role\":\"ADMIN\",\"status\":\"active\"}}";
            }
            if (path.startsWith("/api/auth/logout")) { prefs.edit().putBoolean("session",false).apply(); return "{\"ok\":true}"; }
            if (path.startsWith("/api/auth/factory-reset") && "POST".equalsIgnoreCase(method)) {
                JSONObject b=bodyObject(body);
                if (!"RESET".equals(b.optString("confirm",""))) return "{\"error\":\"Reset confirmation required.\"}";
                try { prefs.edit().clear().commit(); context.getSharedPreferences("WebView", Context.MODE_PRIVATE).edit().clear().apply(); return "{\"ok\":true,\"message\":\"All local app data reset.\"}"; }
                catch(Exception e){ return "{\"error\":\"Could not reset local app data.\"}"; }
            }
            if (path.startsWith("/api/auth/me")) {
                boolean configured=prefs.contains("username") && prefs.contains("password_hash") && prefs.getBoolean("session",false);
                if(!configured) return "{\"logged_in\":false}";
                return "{\"logged_in\":true,\"user\":{" + "\"id\":1,\"username\":" + JSONObject.quote(prefs.getString("username","Android User")) + ",\"role\":\"ADMIN\",\"status\":\"active\"}}";
            }
            if (path.startsWith("/api/account/credentials") && "POST".equalsIgnoreCase(method)) {
                JSONObject b=bodyObject(body); String old=b.optString("current_password",""), np=b.optString("new_password",""); String sh=prefs.getString("password_hash","");
                try { if(sh.isEmpty() || !hash(old).equals(sh)) return "{\"error\":\"Current password is incorrect.\"}"; if(np.length()>0 && np.length()<8) return "{\"error\":\"New password must be 8+ characters.\"}"; if(np.length()>=8) prefs.edit().putString("password_hash",hash(np)).apply(); String nu=b.optString("new_username",prefs.getString("username","Admin")).trim(); if(nu.length()<3) return "{\"error\":\"Username must be at least 3 characters.\"}"; prefs.edit().putString("username",nu).apply(); return "{\"ok\":true,\"message\":\"Account updated locally.\",\"user\":{" + "\"id\":1,\"username\":" + JSONObject.quote(nu) + ",\"role\":\"ADMIN\"}}"; } catch(Exception e){return "{\"error\":\"Could not update credentials.\"}";}
            }
            if (path.startsWith("/api/settings")) return "{\"sound_enabled\":true,\"sound_volume\":0.45,\"theme\":\"dark\",\"zoom\":1.0,\"fullscreen\":true}";
            if (path.startsWith("/api/access/features")) return "{\"plan\":\"ANDROID_LOCAL\",\"features\":[\"all\"],\"restricted\":false}";
            if (path.startsWith("/api/ai/models")) return "{\"ollama\":{\"installed\":false,\"running\":false,\"models\":[],\"error\":\"AI runtimes are not bundled; offline GUI mode remains available.\"},\"gguf_models\":[],\"gguf_search_dirs\":[],\"llama_cpp_python_installed\":false,\"note\":\"Android GUI mode does not fabricate AI models.\"}";
            if (path.startsWith("/api/system")) return systemStatusJson();
            if (path.startsWith("/api/health")) return "{\"status\":\"ok\",\"mode\":\"Android GUI\"}";
            if (path.startsWith("/api/app-health")) return "{\"status\":\"ok\",\"checks\":[]}";
            if (path.startsWith("/api/control-center")) return "{\"status\":\"Android GUI\",\"network\":\"device-controlled\",\"bluetooth\":\"device-controlled\"}";
            if (path.startsWith("/api/terminal/run")) return "{\"ok\":false,\"output\":\"Terminal backend is not bundled. Install Termux separately to use the optional Termux bridge.\"}";
            if (path.startsWith("/api/diagnostics")) return "{\"checks\":[{\"name\":\"Android GUI\",\"ok\":true,\"detail\":\"WebView desktop shell loaded.\"},{\"name\":\"Local security\",\"ok\":true,\"detail\":\"Credentials are stored as local password hashes.\"},{\"name\":\"Network state\",\"ok\":" + isOnline() + ",\"detail\":\"Internet is currently \" + (isOnline()?\"available\":\"unavailable\") + \".\"}]}";
            return "{\"ok\":true,\"items\":[],\"data\":[],\"message\":\"Android GUI offline compatibility mode\"}";
        } catch (Exception e) {
            return "{\"error\":\"Android compatibility response failed\"}";
        }
    }
}
