/* DevX OS V3.0 release enhancements: safe, local-only helpers. */
(function(){'use strict';
  const $=(s,r=document)=>r.querySelector(s);
  const notify=(title,message)=>{if(typeof window.showDevxNotification==='function')window.showDevxNotification(title,message,'info');else console.info('[DevX]',title,message);};
  // Remove duplicate icon-only controls with the same action/title, preserving the first accessible button.
  function dedupeIconButtons(){
    const scope=$('#taskbar'); if(!scope)return;
    const seenIds=new Set();
    scope.querySelectorAll('button.tbtn,button[data-icon]').forEach(b=>{
      if(b.id){ if(seenIds.has(b.id)){b.remove();return;} seenIds.add(b.id); }
      // Keep separate controls even if their icons look alike; only exact duplicate IDs are removed.
      const icon=b.querySelector('svg'); if(icon){icon.style.pointerEvents='none';icon.setAttribute('aria-hidden','true');}
    });
  }

  // V3.3: never inject the backup panel into the desktop/window layer.
  // It belongs inside Settings only, so the normal desktop remains visible.
  function fixV33DesktopAndSearch(){
    const backup=$('#v3-backup-card');
    const settingsWindow=$('.win[data-app="settings"], #settings-window, [data-app-window="settings"]');
    if(backup && (!settingsWindow || !settingsWindow.contains(backup))) backup.remove();
    const taskbar=$('#taskbar');
    if(taskbar){
      const candidates=[...taskbar.querySelectorAll('button,[role="button"]')].filter(b=>{
        const label=((b.id||'')+' '+(b.getAttribute('aria-label')||'')+' '+(b.title||'')+' '+(b.dataset.icon||'')+' '+(b.textContent||'')).toLowerCase();
        return /search|magnifying/.test(label)||!!b.querySelector('svg[data-lucide="search"],svg.lucide-search');
      });
      const primary=taskbar.querySelector('#taskbar-search-btn')||candidates[0];
      candidates.forEach(b=>{if(b!==primary)b.remove();});
    }
    // Remove floating Permissions controls, but keep Settings/Quick Settings permission entries.
    document.querySelectorAll('button,a,[role="button"]').forEach(el=>{
      if(el.closest('#devx-quick-panel,#quick-settings-panel,#quick-settings,.quick-settings-panel,[aria-label="Quick Settings"],.win[data-app="settings"],#settings-window,[data-app-window="settings"],[data-pane="permissions"],#app-launcher,#launcher-panel,#launcher,#launcher-grid,.launcher-grid'))return;
      const label=((el.textContent||'').trim().replace(/\s+/g,' ')+' '+(el.title||'')+' '+(el.getAttribute('aria-label')||'')).trim().toLowerCase();
      const idcls=((el.id||'')+' '+(typeof el.className==='string'?el.className:'')).toLowerCase();
      const exact=/^(permissions|permission center)(\s|$)/.test(label);
      if(exact||/desktop-permission|floating-permission|permission-open|v34-desktop-permissions/.test(idcls))el.remove();
    });
  }
  // Battery API is optional in WebViews; keep a useful fallback instead of displaying a broken icon.
  async function battery(){const el=$('#battery-widget');if(!el)return;try{if(!navigator.getBattery)throw Error('unsupported');const b=await navigator.getBattery();const paint=()=>{const n=Math.round(b.level*100);el.innerHTML=`<span class="v3-battery-glyph" aria-hidden="true">${b.charging?'ϟ':'▰'}</span><span>${n}%</span>`;el.title=`Battery ${n}%${b.charging?' · charging':' · not charging'}`;el.setAttribute('aria-label',el.title);};paint();b.addEventListener('levelchange',paint);b.addEventListener('chargingchange',paint);}catch(_){el.textContent='Battery';el.title='Battery percentage is unavailable in this browser. Open Android battery settings for details.';}}
  // System monitor card reads the existing API only; if unavailable, report that honestly.
  async function monitor(){try{const r=await fetch('/api/system',{cache:'no-store'});const j=await r.json();return `CPU ${j.cpu_percent??'n/a'}% · RAM ${j.ram_used_percent??'n/a'}%`;}catch(_){return 'CPU/RAM details unavailable in this runtime';}}
  function wireBackup(){const target=$('.win[data-app="settings"] .win-body, #settings-window .win-body, #settings-window .window-body, [data-app-window="settings"] .win-body');if(!target||$('#v3-backup-card',target))return;const card=document.createElement('section');card.id='v3-backup-card';card.className='note-card';card.innerHTML='<b>V3.0 · Local Backup & Recovery</b><p class="dim">Export or restore DevX desktop preferences stored in this browser. This does not back up personal files or Android system settings.</p><div class="row"><button type="button" class="btn" id="v3-export-settings">Export Settings</button><button type="button" class="btn" id="v3-import-settings">Restore Settings</button><input type="file" id="v3-import-file" accept="application/json,.json" hidden></div><div class="dim" id="v3-backup-status" role="status"></div>';
    target.appendChild(card);
    $('#v3-export-settings',card).onclick=()=>{try{const keys=[];for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&(/devx|hcr|theme|wallpaper|desktop|sound/i).test(k))keys.push(k);}const data={format:'devx-settings-backup',version:1,createdAt:new Date().toISOString(),settings:Object.fromEntries(keys.map(k=>[k,localStorage.getItem(k)]))};const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));a.download='devx-os-settings-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);$('#v3-backup-status',card).textContent=`Exported ${keys.length} preference entries.`;}catch(e){$('#v3-backup-status',card).textContent='Export failed: '+e.message;}};
    $('#v3-import-settings',card).onclick=()=>$('#v3-import-file',card).click();
    $('#v3-import-file',card).onchange=async e=>{const f=e.target.files?.[0];if(!f)return;try{const j=JSON.parse(await f.text());if(j.format!=='devx-settings-backup'||!j.settings||typeof j.settings!=='object')throw Error('Not a valid DevX settings backup');if(!confirm('Restore these DevX preferences? Existing matching preferences will be replaced.'))return;let count=0;for(const [k,v] of Object.entries(j.settings)){if(/^(devx|hcr|theme|wallpaper|desktop|sound)/i.test(k)&&typeof v==='string'){localStorage.setItem(k,v);count++;}}$('#v3-backup-status',card).textContent=`Restored ${count} preference entries. Reload DevX OS to apply all changes.`;}catch(err){$('#v3-backup-status',card).textContent='Restore failed: '+err.message;}finally{e.target.value='';}};
  }
  function fixSearch(){
    const taskbar=$('#taskbar');if(!taskbar)return;
    const input=$('#taskbar-search-input');let btn=$('#taskbar-search-btn');
    const candidates=[...taskbar.querySelectorAll('button,[role="button"]')].filter(b=>{
      const label=((b.id||'')+' '+(b.title||'')+' '+(b.getAttribute('aria-label')||'')+' '+(b.dataset.icon||'')).toLowerCase();
      return /search|magnifying/.test(label)||!!b.querySelector('svg[data-lucide="search"],svg.lucide-search');
    });
    if(!btn)btn=candidates[0]||null;
    candidates.forEach(b=>{if(b!==btn)b.remove();});
    if(!btn)return;
    btn.setAttribute('aria-label','Search apps');btn.title='Search apps';btn.dataset.v35CanonicalSearch='1';
    const svg='<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.6"></circle><path d="m16 16 4.5 4.5"></path></svg>';
    if(btn.children.length!==1 || btn.firstElementChild?.tagName?.toLowerCase()!=='svg' || btn.querySelectorAll('svg').length!==1 || !btn.querySelector('svg circle'))btn.innerHTML=svg;
    const wrap=input?.closest('.taskbar-search')||taskbar.querySelector('.taskbar-search');
    if(wrap){wrap.style.display='flex';wrap.style.alignItems='center';wrap.style.gap='0';wrap.querySelectorAll(':scope > svg,:scope > .vector-ui-icon,:scope > [data-icon="search"],:scope > button:not(#taskbar-search-btn)').forEach(x=>x.remove());}
    if(input){input.autocomplete='off';input.spellcheck=false;input.style.backgroundImage='none';}
  }
  function wireAdminMenu(){
    const user=$('#user-widget');if(!user)return;
    let trigger=user.querySelector('#v31-admin-menu-btn, .admin-session-trigger');
    if(!trigger){trigger=document.createElement('button');trigger.id='v31-admin-menu-btn';trigger.type='button';trigger.className='btn admin-session-trigger';trigger.textContent='ADMIN ▾';user.appendChild(trigger);}
    let menu=$('#v31-admin-menu');
    if(!menu){menu=document.createElement('div');menu.id='v31-admin-menu';menu.className='v31-admin-menu';menu.hidden=true;menu.setAttribute('role','menu');menu.innerHTML='<div class="admin-menu-title">Account & session</div><button type="button" role="menuitem" data-admin-action="remember">Remember me: <span id="v34-remember-state">OFF</span></button><button type="button" role="menuitem" data-admin-action="shutdown">Shut down DevX OS</button><button type="button" role="menuitem" data-admin-action="reboot">Reboot DevX OS</button><button type="button" role="menuitem" data-admin-action="logout">Log out</button>';document.body.appendChild(menu);}
    if(!trigger.dataset.v35Wired){
      trigger.dataset.v35Wired='1';trigger.type='button';trigger.setAttribute('aria-haspopup','menu');trigger.setAttribute('aria-controls','v31-admin-menu');trigger.title='Click to open account and session options';
      trigger.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();const now=menu.hidden;menu.hidden=!now;trigger.setAttribute('aria-expanded',String(now));const s=$('#v34-remember-state');if(s)s.textContent=localStorage.getItem('devx.remember-session')==='true'?'ON':'OFF';if(now){const r=trigger.getBoundingClientRect();menu.style.right=Math.max(8,window.innerWidth-r.right)+'px';menu.style.bottom='calc(var(--devx-taskbar-height,48px) + 8px)';}});
    }
    if(!menu.dataset.v35Wired){
      menu.dataset.v35Wired='1';
      menu.addEventListener('click',async e=>{const b=e.target.closest('[data-admin-action]');if(!b)return;const a=b.dataset.adminAction;menu.hidden=true;const t=$('#v31-admin-menu-btn');if(t)t.setAttribute('aria-expanded','false');
        if(a==='remember'){const on=localStorage.getItem('devx.remember-session')!=='true';try{localStorage.setItem('devx.remember-session',String(on));}catch(_){}notify('Remember me',on?'Enabled on this device. This only remembers this preference; it does not bypass sign-in.':'Disabled on this device.');const s=$('#v34-remember-state');if(s)s.textContent=on?'ON':'OFF';}
        else if(a==='reboot'){if(confirm('Restart the DevX OS interface? Unsaved work may be lost.'))location.reload();}
        else if(a==='shutdown'){if(confirm('Close the DevX OS interface? You can start it again by reloading this page.')){document.body.innerHTML='<main style="min-height:100dvh;display:grid;place-items:center;background:#0b1020;color:#e8edff;font:16px system-ui;text-align:center;padding:24px"><div><h1>DevX OS is shut down</h1><p>Android is still running. Reload this page to reopen DevX OS.</p><button id="devx-start-again" style="padding:12px 20px;border-radius:10px">Start DevX OS</button></div></main>';document.getElementById('devx-start-again').onclick=()=>location.reload();}}
        else if(a==='logout'){if(confirm('Log out of the current session?')){if(typeof window.logout==='function')await window.logout();else location.reload();}}
      });
    }
  }
  function wireOnlineStatus(){
    const net=$('#net-status');if(!net||net.dataset.v31status)return;net.dataset.v31status='1';net.style.cursor='pointer';net.title='Tap to view system network status';
    net.addEventListener('click',async()=>{
      const online=navigator.onLine;
      let internet='Not verified';
      if(online){try{const c=new AbortController();const t=setTimeout(()=>c.abort(),3500);const r=await fetch('/favicon.ico?statusCheck='+Date.now(),{method:'GET',cache:'no-store',signal:c.signal});clearTimeout(t);internet=r.ok?'Local server reachable; public Internet not independently verified':'Server responded with HTTP '+r.status;}catch(_){internet='Browser reports a network, but a fresh Internet check failed.';}}
      else internet='Browser reports Offline.';
      notify('System Status',`Network: ${online?'Connected':'Offline'} · ${internet}`);
    });
  }

  // V3.4: first-visit boot splash only, shown once for ten seconds. Existing auth flow continues underneath.
  function firstVisitBoot(){
    let seen=false;try{seen=localStorage.getItem('devx.v34.boot-seen')==='1';}catch(_){}
    if(seen)return;
    const splash=document.createElement('div');splash.id='devx-v34-first-boot';splash.innerHTML='<div class="v34-boot-mark">DX</div><h1>DevX OS</h1><p>Starting your desktop…</p><div class="v34-boot-track"><span></span></div><small>First startup</small>';
    document.body.appendChild(splash);
    const st=Date.now();const tick=()=>{const left=Math.max(0,10000-(Date.now()-st));const p=splash.querySelector('.v34-boot-track span');if(p)p.style.width=((10000-left)/10000*100)+'%';if(left<=0){try{localStorage.setItem('devx.v34.boot-seen','1');}catch(_){}splash.classList.add('v34-done');setTimeout(()=>splash.remove(),350);}else setTimeout(tick,100);};tick();
  }
  function movePermissionIntoQuickSettings(){
    // Permission Center is no longer a floating desktop button. Add a shortcut beside network controls if a Quick Settings panel exists.
    const panel=document.querySelector('#devx-quick-panel, #quick-settings-panel, #quick-settings, .quick-settings-panel, [aria-label="Quick Settings"]');
    if(!panel||panel.querySelector('#v34-permissions-shortcut,[data-q="permissions"]'))return;
    const b=document.createElement('button');b.id='v34-permissions-shortcut';b.type='button';b.className='quick-setting';b.textContent='Permissions';b.title='Open Android permission settings';
    b.addEventListener('click',()=>{if(window.AndroidHCR&&typeof AndroidHCR.openSettings==='function'){try{AndroidHCR.openSettings('android.settings.APPLICATION_DETAILS_SETTINGS');notify('Permissions','Review permissions in Android App Info.');}catch(_){notify('Permissions','Open Android Settings → Apps → DevX OS → Permissions.');}}else notify('Permissions','Open Android Settings → Apps → DevX OS → Permissions.');});panel.appendChild(b);
  }


  // V3.4.1: keep only one magnifier control and remove stray desktop Permission buttons.
  function repairDesktopControls(){
    const taskbar=$('#taskbar');
    if(taskbar){
      const all=[...taskbar.querySelectorAll('button,[role="button"]')];
      const candidates=all.filter(b=>{const t=((b.id||'')+' '+(b.title||'')+' '+(b.getAttribute('aria-label')||'')+' '+(b.dataset.icon||'')+' '+(b.textContent||'')).toLowerCase();return /search|magnifying/.test(t)||!!b.querySelector('svg[data-lucide="search"],svg.lucide-search');});
      const keep=taskbar.querySelector('#taskbar-search-btn')||candidates[0];
      candidates.forEach(b=>{if(b!==keep)b.remove();});
      if(keep){
        const svgs=[...keep.querySelectorAll('svg')];svgs.slice(1).forEach(icon=>icon.remove());
        keep.querySelectorAll('.vector-ui-icon,[data-icon="search"]').forEach(icon=>{if(icon!==keep.querySelector('svg'))icon.remove();});
      }
      taskbar.querySelectorAll('.taskbar-search > svg, .taskbar-search > .vector-ui-icon, .taskbar-search > [data-icon="search"]').forEach(icon=>icon.remove());
      const input=taskbar.querySelector('#taskbar-search-input');if(input){input.style.backgroundImage='none';input.style.paddingLeft='9px';}
    }
    const protectedSelectors='#devx-quick-panel,#quick-settings-panel,#quick-settings,.quick-settings-panel,[aria-label="Quick Settings"],.win[data-app="settings"],#settings-window,[data-app-window="settings"],[data-pane="permissions"],#app-launcher,#launcher-panel,#launcher,#launcher-grid,.launcher-grid';
    document.querySelectorAll('button,a,[role="button"]').forEach(el=>{
      if(el.closest(protectedSelectors))return;
      const label=((el.textContent||'').trim().replace(/\s+/g,' ')+' '+(el.title||'')+' '+(el.getAttribute('aria-label')||'')).trim().toLowerCase();
      const idcls=((el.id||'')+' '+(typeof el.className==='string'?el.className:'')).toLowerCase();
      const position=(()=>{try{return getComputedStyle(el).position}catch(_){return el.style.position||''}})();
      const named=/^(permissions|permission center)(?:\s|$)/.test(label);
      const explicit=/desktop-permission|floating-permission|permission-open|v34-desktop-permissions/.test(idcls);
      if(named||explicit)el.remove();
      else if(position==='fixed' && /permission/.test(label))el.remove();
    });
    // Backup & Recovery is a Settings tool, not desktop wallpaper/content.
    const backup=$('#v3-backup-card');
    if(backup&&!backup.closest('.win[data-app="settings"],#settings-window,[data-app-window="settings"]'))backup.remove();
  }

  function wire(){dedupeIconButtons(); fixV33DesktopAndSearch();fixSearch();repairDesktopControls();battery();movePermissionIntoQuickSettings();const date=$('#date-widget'),clock=$('#clock-widget');if(date)date.title='Double-tap to edit desktop date';if(clock)clock.title='Double-tap to edit desktop time';wireBackup();wireAdminMenu();wireOnlineStatus();
    // Expose a lightweight diagnostic action for runtimes with no backend.
    const net=$('#net-status');if(net&&!net.dataset.v3diag){net.dataset.v3diag='1';net.addEventListener('contextmenu',async e=>{e.preventDefault();notify('Network diagnostics',await monitor());});}
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{firstVisitBoot();wire();},{once:true});else {firstVisitBoot();wire();}
  try{new MutationObserver(()=>{wireBackup();wireAdminMenu();wireOnlineStatus();movePermissionIntoQuickSettings();repairDesktopControls();}).observe(document.body,{childList:true,subtree:true});}catch(_){}
})();

