# DevX OS App Sound Map

Every registered app has a dedicated WAV file under `apps/`. The frontend maps app IDs to these files and plays the app-specific sound when opening/closing the app.
