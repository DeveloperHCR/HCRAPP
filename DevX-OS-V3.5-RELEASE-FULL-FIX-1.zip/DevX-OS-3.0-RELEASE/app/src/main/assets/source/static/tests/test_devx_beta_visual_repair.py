from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app.js"
INDEX = ROOT / "index.html"
STYLE = ROOT / "style.css"

def test_no_blank_taskbar_controls():
    text = INDEX.read_text()
    assert 'id="mouse-mode-btn"' in text and 'data-icon="mouse"' in text
    assert 'id="landscape-btn"' in text and 'data-icon="landscape"' in text
    assert 'id="taskbar-search-btn"' in text and 'data-icon="search"' in text

def test_setup_guide_and_data_secret_present():
    text = APP.read_text()
    assert 'function showSetupGuide()' in text
    assert 'function openDataSecretSettings()' in text
    assert '/^DATA$/i.test(text)' in text
    assert 'data-secret-settings' in text

def test_desktop_defaults_have_real_shortcuts():
    text = APP.read_text()
    assert 'const DEFAULT_DESKTOP_APPS=["files","recyclebin","thispc","setup","settings","aichat"]' in text
    assert 'hcr-show-desktop-icons' in text

def test_missing_wallpaper_assets_were_added():
    for ref in [
      'wallpapers/hd/cyber-grid-hd.png', 'wallpapers/hd/deep-space-hd.png',
      'assets/wallpapers/aurora-neon.png', 'assets/v21/aurora-lattice.png',
      'assets/v22/midnight-circuit.png', 'assets/wallpapers/v23/01-quantum-rain-4k.jpg'
    ]:
        assert (ROOT / ref).exists(), ref

def test_resize_fix_is_bounded():
    text = APP.read_text()
    assert 'const maxW=' in text and 'const maxH=' in text and 'Math.min(maxW' in text
