# DevX OS — Main Hint

Welcome to the DevX OS hint system. This is the **main hint**. The app exposes only this main hint download after the About session is completed.

## How the hint system is organized

- **Setup** — first-run/admin setup and About completion
- **Desktop** — desktop, windows, taskbar and icons
- **AI** — AI workspace and normal AI tools
- **Browser & Network** — browser and real Internet status
- **Files** — File Manager, Recycle Bin and This PC
- **Settings** — settings and customization
- **Tools** — built-in utilities
- **Developer** — coding and Python app-building workflow
- **Troubleshoot & Recovery** — diagnostics and recovery

## Main rule

Keep this file as the main hint. Individual feature hints can be published in separate repositories and linked from the main hint later.

## Sound system

DevX OS uses separate bundled sounds for major apps and system actions. Each registered app has its own opening sound so applications do not all use the same sound.

## Security

Hints must not contain real passwords, API keys, access tokens, or authentication bypass instructions. Private configuration should use legitimate owner/admin controls only.

## Release flow

1. Finish the About session in DevX OS.
2. The **Download Main Hint** option appears.
3. Download this main hint.
4. Individual feature hints can be maintained separately.
