# V3.0 RELEASE — Support & Admin UI Fix

## Support contacts
- Official support email: `developerhcr@gmail.com`
- Official Instagram support: `https://www.instagram.com/developerhcr?igsh=MW8wZ2M2MHk0MDAw`
- GitHub repository remains available from Support and Admin Dashboard.
- WhatsApp support has been removed from the V3.0 RELEASE UI and defaults.

## Admin safety
- Existing Admin login, username and password flow is unchanged.
- Support settings do not modify Admin credentials.
- Admin Dashboard now has a dedicated Support Team card with Email, Instagram and GitHub actions.

## UI
- Feedback & Support has a cleaner contact card.
- Mobile layout stacks contact rows for easier touch use.
- No broken `support` variable or WhatsApp dependency is required.

## Verification
- Python syntax: PASS
- JavaScript syntax: PASS
- Test suite: PASS (46 tests)
