# DevX OS V3.0 RELEASE — Final UI and Shell Fix

## Changes

- Compact Windows-style windows with screen-boundary protection.
- Settings redesigned for compact navigation and Android touch.
- Settings account area includes optional display name, Remember-device preference and Switch/Second Login.
- Biometrics are not used.
- Validation and error notifications can be disabled in Settings.
- Username validation rejects values shorter than 3 characters with a clear message.
- Network status indicator uses green for online and red for offline.
- Quick Settings button is placed beside the date/time area.
- The taskbar open-app tray is icon-only for multiple open apps.
- Unneeded secondary taskbar controls are hidden to keep the shell compact.
- Pointer mode hides the virtual touchpad/helper UI and shows only the pointer.
- App Store cards, About and launcher use recognizable vector icons.
- Admin Dashboard and Setup Center content is clipped to the available window instead of overflowing.
- Hidden Secret Hunt now uses the requested twist: REAL and FAKE are both decoys and the correct action is direct Submit without selecting either.
- DevX Connect adds a communication workspace shell with local-first chat and honest device/network integration; remote calling/chat requires an actual signalling/backend service.
- Bluetooth distance is hardware/standard dependent; the app does not claim to amplify Bluetooth to 1–2 km.
