@echo off
setlocal
REM DevX OS Windows launcher
REM Python installer/download: https://www.python.org/
where python >nul 2>nul
if errorlevel 1 (
  echo Python is not installed. Install Python from https://www.python.org/ and try again.
  exit /b 1
)
if not exist requirements.txt (
  echo requirements.txt not found.
  exit /b 1
)
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo pip install failed. Check your network and Python environment.
  exit /b 1
)
python windows_app.py
endlocal
