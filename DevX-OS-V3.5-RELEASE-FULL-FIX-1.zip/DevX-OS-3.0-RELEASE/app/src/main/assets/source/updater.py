#!/usr/bin/env python3
"""Safe local updater helper for DevX OS.

This helper never deletes the data directory and refuses to overwrite it.
It is intentionally local-only; fetching remote releases belongs to the app/update service.
"""
from __future__ import annotations
import argparse, shutil, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"


def backup_source() -> Path:
    stamp = time.strftime("%Y%m%d-%H%M%S")
    out = ROOT.parent / f"devx-backup-{stamp}"
    shutil.copytree(ROOT, out, ignore=shutil.ignore_patterns("data", "__pycache__", ".pytest_cache"))
    return out


def apply_local_release(release_dir: Path) -> None:
    release_dir = release_dir.resolve()
    if not release_dir.is_dir():
        raise SystemExit(f"Release directory not found: {release_dir}")
    for item in release_dir.iterdir():
        if item.name == "data":
            continue
        target = ROOT / item.name
        if item.is_dir():
            if target.exists():
                shutil.rmtree(target)
            shutil.copytree(item, target)
        else:
            shutil.copy2(item, target)


def main() -> int:
    ap = argparse.ArgumentParser(description="DevX OS local updater")
    ap.add_argument("--backup", action="store_true", help="Create a source backup first")
    ap.add_argument("--release-dir", type=Path, help="Copy a validated local release tree into the source tree")
    args = ap.parse_args()
    if not args.backup and not args.release_dir:
        ap.error("choose --backup or --release-dir")
    if args.backup:
        print(f"Backup created: {backup_source()}")
    if args.release_dir:
        if args.backup is False:
            print(f"Creating safety backup: {backup_source()}")
        apply_local_release(args.release_dir)
        print("Update applied. The data/ directory was preserved.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
