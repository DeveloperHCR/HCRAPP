from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ANDROID_NS = {"a": "http://schemas.android.com/apk/res/android"}

def test_android_manifest_declares_runtime_permissions():
    root = ET.parse(ROOT.parents[4] / "app/src/main/AndroidManifest.xml").getroot()
    perms = {e.attrib["{http://schemas.android.com/apk/res/android}name"] for e in root.findall("uses-permission")}
    for p in [
        "android.permission.INTERNET", "android.permission.CAMERA",
        "android.permission.RECORD_AUDIO", "android.permission.POST_NOTIFICATIONS",
        "android.permission.BLUETOOTH_SCAN", "android.permission.BLUETOOTH_CONNECT",
        "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO",
    ]:
        assert p in perms

def test_android_permission_bridge_and_storage_picker_present():
    java = (ROOT.parents[4] / "app/src/main/java/com/developerhcr/codeassist/AndroidApiBridge.java").read_text()
    assert "permissionStatus()" in java
    assert "requestPermissions(String csv)" in java
    assert "openStoragePicker()" in java
    assert "selectedStorageList()" in java
    assert "DocumentsContract" in java

def test_frontend_permission_center_and_safe_validation_present():
    js = (ROOT / "static" / "app.js").read_text()
    assert 'data-pane="permissions"' in js
    assert 'devx-permissions-request' in js
    assert 'devx-permissions-storage' in js
    assert 'Username must contain at least 3 characters.' in js
    assert 'q==="permissions"' in js
