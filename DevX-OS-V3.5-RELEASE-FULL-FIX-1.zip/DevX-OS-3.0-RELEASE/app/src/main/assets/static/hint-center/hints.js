const HINTS = [
  {
    "id": "internet-online",
    "category": "Internet & Network",
    "title": "Wi-Fi connected but DevX OS says Offline",
    "summary": "A network icon only means a network is attached; it does not prove public Internet access.",
    "steps": [
      "Open a trusted website in the normal browser to confirm Internet access.",
      "In DevX OS choose Troubleshoot → Run Diagnostics and wait for the result.",
      "Check that the request tests a real HTTPS endpoint and checks response.ok; do not set Online from Wi-Fi state alone.",
      "If only one endpoint fails, retry with a second trusted endpoint and show Unknown when checks are blocked."
    ],
    "warning": "Never display Online simply because Android reports Wi-Fi connected."
  },
  {
    "id": "json-diagnostics",
    "category": "Troubleshoot & Recovery",
    "title": "“Failed to execute json on Response”",
    "summary": "The server may have returned HTML, empty text, or malformed JSON instead of JSON.",
    "steps": [
      "Read the response as text first.",
      "Check the HTTP status and Content-Type header.",
      "Try JSON.parse inside try/catch; if parsing fails, show a short safe error and keep the raw body out of the UI.",
      "Make the server return valid JSON consistently, including for errors."
    ],
    "warning": "Do not assume every response body is valid JSON."
  },
  {
    "id": "diagnostics-timeout",
    "category": "Troubleshoot & Recovery",
    "title": "Diagnostics keeps spinning",
    "summary": "A network request may be blocked or never finish.",
    "steps": [
      "Use an AbortController with a reasonable timeout (for example 8–10 seconds).",
      "Show a timeout message and let the user retry.",
      "Cancel duplicate checks when a newer check starts.",
      "Record which check failed in the report."
    ]
  },
  {
    "id": "reset-safe",
    "category": "Troubleshoot & Recovery",
    "title": "Before using Reset All Data",
    "summary": "Reset may remove local settings or files.",
    "steps": [
      "Export important user-created data first.",
      "Read the confirmation summary carefully.",
      "Require a clear second confirmation for destructive reset.",
      "Restart and run diagnostics after reset."
    ],
    "warning": "A reset should never secretly upload or expose personal data."
  },
  {
    "id": "browser-offline",
    "category": "Browser",
    "title": "Browser says no connection",
    "summary": "Distinguish browser loading errors from the OS connectivity indicator.",
    "steps": [
      "Test another HTTPS website.",
      "Check device date and time if TLS certificates fail.",
      "Disable airplane mode and verify mobile data or Wi-Fi is enabled.",
      "If websites work but the OS remains Offline, capture the diagnostics report for the developer."
    ]
  },
  {
    "id": "settings-not-saving",
    "category": "Settings",
    "title": "Settings do not persist",
    "summary": "Local storage may be blocked, full, or cleared.",
    "steps": [
      "Change one harmless setting and reload the app.",
      "Check whether the app uses localStorage or a backend API for that setting.",
      "Catch storage exceptions and display a useful message.",
      "Use export/import for user preferences if supported."
    ]
  },
  {
    "id": "icons-missing",
    "category": "Desktop & Icons",
    "title": "Desktop icons are blank",
    "summary": "An icon resource may be missing or a stylesheet may not load.",
    "steps": [
      "Check browser developer logs for missing asset paths.",
      "Confirm icon names exist in the icon registry.",
      "Use bundled SVG icons rather than remote image URLs or emoji placeholders.",
      "Clear stale cache only after confirming the updated assets are packaged."
    ]
  },
  {
    "id": "app-not-opening",
    "category": "Apps",
    "title": "An app will not open",
    "summary": "The app may not be registered, unlocked, or available to the current profile.",
    "steps": [
      "Confirm its app ID appears once in the app registry.",
      "Check console errors for the app renderer.",
      "Verify permissions and feature gating.",
      "Test opening, closing, reopening, and restoring the window."
    ]
  },
  {
    "id": "sound",
    "category": "Sounds",
    "title": "App sounds are missing",
    "summary": "Audio can be blocked until the user interacts with the app.",
    "steps": [
      "Tap or click once to enable audio playback.",
      "Check sound settings and device volume.",
      "Confirm the sound file exists in the packaged assets and its path is correct.",
      "Keep sound optional and provide a mute toggle."
    ]
  },
  {
    "id": "storage",
    "category": "File Manager",
    "title": "Files or storage not visible",
    "summary": "WebView storage access differs from native Android file access.",
    "steps": [
      "Check the file picker and permissions used by the app.",
      "Request only the permissions required for the feature.",
      "Handle permission denial with an explanation.",
      "Never assume the app can access every Android folder."
    ]
  },
  {
    "id": "ai-offline",
    "category": "AI & Models",
    "title": "Local AI is not responding",
    "summary": "A model may be missing, unsupported, or too large for available memory.",
    "steps": [
      "Check the selected model path and file size.",
      "Confirm the chosen runtime is installed and running.",
      "Try a smaller quantized model if the device runs out of memory.",
      "Show a clear Offline/Unavailable state when no model responds."
    ]
  },
  {
    "id": "privacy",
    "category": "Security & Privacy",
    "title": "Keep private settings private",
    "summary": "Hints and logs should not contain real credentials.",
    "steps": [
      "Store secrets in a secure credential store where available.",
      "Mask tokens in logs and diagnostic exports.",
      "Require authentication for private owner settings.",
      "Use a documented account recovery flow rather than a hidden password bypass."
    ],
    "warning": "Never place passwords, API keys, tokens, or recovery codes in this app."
  },
  {
    "id": "update-assets",
    "category": "Developer",
    "title": "Updated UI does not appear",
    "summary": "The app may load a different copy of an asset than the one edited.",
    "steps": [
      "Search for all copies of index.html and app.js.",
      "Identify the exact asset path loaded by MainActivity.",
      "Update the runtime copy and any maintained source copy consistently.",
      "Rebuild and reinstall the APK; verify the displayed version."
    ]
  },
  {
    "id": "webview-cache",
    "category": "Developer",
    "title": "Old page appears after rebuilding",
    "summary": "A WebView or browser may still display cached assets.",
    "steps": [
      "Increment the local asset version string or use a versioned cache key.",
      "Rebuild and reinstall the app.",
      "Clear app data only if safe and after exporting needed data.",
      "Verify the actual installed APK version."
    ]
  },
  {
    "id": "report-export",
    "category": "Troubleshoot & Recovery",
    "title": "Export a useful diagnostics report",
    "summary": "A small report helps isolate repeatable failures.",
    "steps": [
      "Include timestamp, app version, platform, and individual check outcomes.",
      "Include HTTP status codes and durations when useful.",
      "Remove credentials, private paths, and personal content.",
      "Share the report only with a trusted developer."
    ]
  },
  {
    "id": "startup",
    "category": "Setup & Startup",
    "title": "App is stuck at startup",
    "summary": "A startup task or permission prompt may be blocking the next step.",
    "steps": [
      "Restart the app once.",
      "Check whether a setup screen is hidden behind another panel.",
      "Open Troubleshoot and run diagnostics if available.",
      "If the issue repeats, note the exact screen and app version."
    ]
  },
  {
    "id": "network-permissions",
    "category": "Android",
    "title": "Android network checks fail",
    "summary": "Android apps need network permission and, for connection state, network-state permission.",
    "steps": [
      "Confirm INTERNET and ACCESS_NETWORK_STATE are declared in AndroidManifest.xml.",
      "Rebuild and reinstall after manifest changes.",
      "Test both Wi-Fi and mobile data.",
      "Remember that permissions do not prove Internet access; perform an actual request."
    ]
  },
  {
    "id": "export-import",
    "category": "Backup & Restore",
    "title": "Back up hints and preferences",
    "summary": "A local export can make settings easier to restore.",
    "steps": [
      "Use Export saved hints to create a JSON file.",
      "Keep the backup in a location you control.",
      "Inspect imports and validate their structure before applying them.",
      "Do not import untrusted scripts or executable content."
    ]
  },
  {
    "id": "unknown-status",
    "category": "Internet & Network",
    "title": "When status should say Unknown",
    "summary": "A failed check may mean the endpoint is blocked rather than that the device has no Internet.",
    "steps": [
      "Use Online only after a real request succeeds.",
      "Use Offline when a reliable connectivity check confirms failure.",
      "Use Unknown when checks are unavailable, blocked, or time out.",
      "Show the last-check time and a retry button."
    ]
  },
  {
    "id": "accessibility",
    "category": "Settings & Customization",
    "title": "Improve readability",
    "summary": "Small text and low contrast make troubleshooting harder.",
    "steps": [
      "Keep body text readable on mobile.",
      "Ensure buttons have accessible labels.",
      "Use visible keyboard focus and meaningful headings.",
      "Do not use color alone to convey Online or Error state."
    ]
  },
  {
    "id": "release-check",
    "category": "Developer",
    "title": "Pre-release checklist",
    "summary": "Validate the app before sharing a release.",
    "steps": [
      "Run JavaScript syntax checks and verify ZIP integrity.",
      "Build the APK with the project Gradle wrapper in a configured Android environment.",
      "Test offline, online, timeout, malformed JSON, and reset-confirmation paths.",
      "Test on the target Android device and record any limitations."
    ]
  }
];
