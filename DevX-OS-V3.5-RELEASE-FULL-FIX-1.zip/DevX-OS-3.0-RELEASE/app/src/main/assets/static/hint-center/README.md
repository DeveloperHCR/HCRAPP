# DevX Hint Center 1.0

Offline-first help companion for DevX OS. Includes search, categories, expandable steps, saved hints, copy guide, and export of saved hints. Contains no passwords, API keys, or authentication bypasses.

## Run
- Open `index.html` in a browser. Core hint/search/save features work offline.
- For installable PWA/offline caching, serve this folder over localhost or HTTPS so the service worker can register.

## Android APK source
The separate project archive includes a minimal Android WebView wrapper. Open it in Android Studio and build the APK using Gradle. This source package is not a precompiled APK.
