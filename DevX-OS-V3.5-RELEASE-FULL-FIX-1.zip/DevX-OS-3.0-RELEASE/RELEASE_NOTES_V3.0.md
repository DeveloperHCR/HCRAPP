# DevX OS 3.0 Release — UI & Device Controls

## Fixes
- Improved quick-setting icon rendering for Airplane, Wi-Fi, Internet, Bluetooth, Storage/Files and Permissions.
- Added a taskbar battery indicator using the Web Battery API when exposed by the WebView, with device-settings fallback.
- Double-click date to set a desktop display date and double-click time to set a desktop display time. This does not change Android system date/time.
- Improved taskbar search sizing and icon alignment.
- Storage quick setting uses the existing Android storage picker bridge where available. Android scoped-storage rules may require folder selection; protected drives cannot be silently browsed.
- Preserved Hint Center and existing assets.

## Build status
Source ZIP only. Build and test APK in Android Studio on a real device. Battery percentage depends on WebView support; system date/time and protected files remain controlled by Android permissions.
