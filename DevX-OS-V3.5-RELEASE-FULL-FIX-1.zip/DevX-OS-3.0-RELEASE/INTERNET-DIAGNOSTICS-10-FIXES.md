# DevX OS 2.0.6 BETA — Internet & Recovery Fixes

## Fixes and features
1. Fixed the actual Android WebView entry page (`assets/static/index.html`) rather than only the source-template copy.
2. Replaced fragile `Response.json()` parsing with guarded text-to-JSON parsing for diagnostics.
3. Added HTTP status checks for diagnostic requests.
4. Added a 10-second diagnostic timeout and readable timeout errors.
5. Added cache-busting (`cache: no-store`) for fresh diagnostics.
6. Added an Export Report button that downloads a JSON report.
7. Report includes browser/runtime, language, platform, screen and viewport data.
8. Report checks localStorage availability safely.
9. Report checks sessionStorage availability safely.
10. Report records available network connection hints (effective type/downlink) without treating them as proof of Internet.
11. Added online/offline event listeners to refresh the login Troubleshoot panel.
12. Added network-connection-change listener when supported by the WebView.
13. Hardened Reset All Data response parsing so malformed responses show an error instead of a JSON exception.
14. Reset only proceeds as successful when a valid successful response is received; two-step RESET confirmation remains.
15. Synchronized Android runtime assets with source assets so fixes are actually loaded by the APK.

## Honest status
The UI now handles malformed diagnostic responses without crashing and can export a report. The Online indicator must still be verified on a built APK and device with Wi-Fi/mobile data, DNS and external Internet tested. `navigator.onLine` and connection hints alone are not considered proof of Internet. APK compilation/device testing was not performed in this environment.

## Build
Open this project in Android Studio and build the debug APK after Gradle sync. Test Run Diagnostics, Export Report, Internet state on/off, and Reset All Data only with data you intend to erase.
