# DevHCR APP — Android Gradle project

This project packages the existing DeveloperHCR web desktop UI as a real Android APK.

## What was preserved
- The original `static/` desktop GUI, CSS, JavaScript and bundled assets.
- The original Python backend/source is included under `app/src/main/assets/source/` for reference and optional Termux/server use.
- Windows-style desktop, taskbar, app launcher, movable windows and the existing DeveloperHCR UI are retained.

## Android layer
- Native Java Android Activity.
- Full-screen landscape presentation.
- Android WebView hosts the existing GUI.
- `AndroidApiBridge` provides an offline compatibility API so the GUI can open without a Python server.
- If the existing Python/FastAPI server is running locally on `127.0.0.1:8000` (for example through Termux), the bridge tries that backend first.
- The APK does NOT pretend that Ollama, Python, Wine, Windows EXE execution, or native Linux tools are bundled. Those remain optional external runtimes.

## Build
Open this folder in Android Studio, allow Gradle sync, then:
- Build > Make Project
- Build > Build APK(s)

Command line, when Gradle/Android SDK are installed:
`./gradlew assembleDebug`

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Important
The original project is a Python/FastAPI application, not an Android Gradle application. This Gradle project is therefore an Android GUI/container port, not a direct conversion of FastAPI into Java. The original backend is preserved in the project so it can continue to be run separately (for example in Termux).

## Project identity
DevX OS / Code Assist
Version: 2.0.1 BETA
Created by Abhimanyu Verma

## Android visual fix
The Android build uses local relative asset paths so the GUI loads correctly from `android_asset`. The supplied DeveloperHCR image is used as the boot/login/desktop background and application icon.

## Hidden Love You Studio

The BETA build includes a hidden personalization Easter egg named `Love You Studio`.
It is revealed only after a normal authenticated Admin account whose username is `Love You` (case-insensitive) logs in. It does **not** bypass password authentication.

It provides:
- Background Creator with animated gradients
- Windows-style fresh design preview window
- Coming Soon / future secret modules
- Local preset save and CSS copy

Android system controls remain subject to Android permissions and platform restrictions.


## Permissions

Open Settings → Permissions to review Camera, Microphone, Notifications, Bluetooth and media access. External storage is handled through the Android system document picker so SD cards/USB drives can be selected without unsafe blanket storage access.
