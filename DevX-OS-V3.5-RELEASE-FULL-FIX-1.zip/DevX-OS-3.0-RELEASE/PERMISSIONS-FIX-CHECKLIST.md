# DevX OS V3.0 RELEASE — Permissions Fix Checklist

- Runtime permission bridge for Camera, Microphone, Notifications and Bluetooth.
- Media permissions are requested only on Android versions that support them.
- Storage uses Android Storage Access Framework (folder picker) rather than fake unrestricted access.
- Quick Settings can open supported Android system settings panels.
- Notifications are skipped safely if notification permission is denied.
- Network status reports actual Android connectivity state.
- Admin username login/setup validation rejects values shorter than 3 characters.
- Android system notification uses a dedicated vector notification icon.
- No biometric permission or biometric authentication is added.
