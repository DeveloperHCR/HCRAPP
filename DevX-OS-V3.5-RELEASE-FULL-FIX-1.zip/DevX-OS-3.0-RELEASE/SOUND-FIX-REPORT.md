# DevX OS Sound + Main Hint Fix

- Added 104 unique WAV sounds, one for every registered app ID.
- Added app-specific sound mapping in the frontend.
- App-specific sound plays when an app opens and when its window closes.
- Existing generic UI sounds remain available for clicks, success, errors, notifications and focus.
- Added bundled `hints/MAIN_HINT.md`.
- About screen now has a single Main Hint flow: complete About Session first, then `Download Main Hint` appears.
- The app exposes only this one hint download option from About.
- Added original bundled audio; no external sound URLs are required.
- No passwords, API keys, tokens or authentication bypasses are included.
