# DevX Hint Center integration

Added an offline-first Hint Center to the Android runtime assets at `app/src/main/assets/static/hint-center/`. The runtime `app.js` registers a new `hintcenter` app using the existing app registry and renders the bundled guide in a local iframe.

Standalone Android Studio source is in the companion `DevX-Hint-App-Android` ZIP. To build this integrated OS, open the existing project in Android Studio and build its APK. APK compilation and on-device verification were not performed in this environment.

Hint Center includes 20 guide topics: real Internet checks, malformed JSON, timeouts, reset safety, browser, settings, icons, app launch, sounds, storage, AI models, privacy, asset sync, WebView cache, report export, startup, Android permissions, backups, unknown status, accessibility, and release checks.
